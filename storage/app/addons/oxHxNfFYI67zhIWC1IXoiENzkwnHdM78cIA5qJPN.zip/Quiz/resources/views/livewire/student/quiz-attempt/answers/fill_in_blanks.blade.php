<div class="am-quizsteps_box am-quizsteps_two">
    <div class="am-quizsteps_option">
        @include('quiz::livewire.student.quiz-attempt.answers.components.question-title')
    </div>

    @include('quiz::livewire.student.quiz-attempt.answers.components.question-image')

</div>