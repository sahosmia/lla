<span>
    <span class="am-ans-detail_incorrect"><i class="am-icon-multiply-02"></i></span>
    <em>Not attempted</em>
</span>